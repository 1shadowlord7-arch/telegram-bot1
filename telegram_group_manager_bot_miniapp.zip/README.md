
# Telegram Group Manager Bot

This build includes:

- add to group button
- group settings
- connected channel search
- request system + admin dashboard
- warning system
- bad word filter
- spam detection
- Telegram Mini App game hub
- Tic Tac Toe as a separate game module
- Rock Paper Scissors as a separate game module
- game room pages with player names, profile photos, and friend actions
- friend requests
- friend list with remove support
- room/game structure ready for more games later

## Setup
1. Create a bot with @BotFather.
2. Set environment variables:
   - BOT_TOKEN
   - BOT_USERNAME
   - BASE_URL
   - OWNER_URL
   - UPDATES_CHANNEL_URL
   - SECRET_KEY
3. Install dependencies:
   `pip install -r requirements.txt`
4. Run:
   `python main.py`

## Game structure
- `ttt_game.py` contains Tic Tac Toe only.
- `rps_game.py` contains Rock Paper Scissors only.
- `games.py` is the registry layer.
- Add a future game by creating a new module and registering it in `games.py`.

## Notes
- The search feature indexes channel posts the bot receives after it is added as a member/admin in that channel.
- For group moderation features, make the bot admin in the group.
- For the web dashboard and mini app, set `BASE_URL` to your Render app URL.
- The mini app uses Telegram WebApp init data so it can show the viewer profile and friend controls.
